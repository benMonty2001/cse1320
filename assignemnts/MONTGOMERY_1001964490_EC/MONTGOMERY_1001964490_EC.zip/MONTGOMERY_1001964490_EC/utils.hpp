#pragma once

#include <vector>
#include <string>

using namespace std;

vector<string> tokenizeCSVLine(string);
vector<int> parseZip(string);
long parsePrice(string);
